# Install — seFrCustomerOrders

This zip is **self-contained**. Everything it needs is here.

## Quick deploy (SF CLI)

```bash
# unzip the bundle
unzip seFrCustomerOrders.zip -d seFrCustomerOrders
cd seFrCustomerOrders

# deploy to your demo org
sf project deploy start --source-dir force-app --target-org <your-org-alias>
```

## What's inside

- **LWC bundle** · `force-app/main/default/lwc/seFrCustomerOrders/`
- **Apex classes** · `force-app/main/default/classes/`
  - `SE_FR_CustomerOrdersController.cls` (local)
- **Metadata** · Custom object Visit__c (+ 9 fields + tab)

> If your org already has the standard `Visit` object (Consumer Goods Cloud), do not deploy `Visit__c`: remove `objects/Visit__c` and `tabs/Visit__c.tab-meta.xml` from this bundle and point the component at `Visit`.

> Optional: product images read `Product2.Image_URL__c` (URL field) when it exists in your org (schema-safe: the component works without it). To enable images, create that field or set the `productImageFieldApiName` property to your own image field. It is not bundled because many orgs already have a field with this name and another type.

## Configure

Open App Builder, drop **`SE FR - CustomerOrders`** (or search for it) on the right Lightning page, tune the properties.

See the component README inside this zip for the full property reference.
