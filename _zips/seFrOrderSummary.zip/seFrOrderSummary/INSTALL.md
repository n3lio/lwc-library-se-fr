# Install — seFrOrderSummary

This zip is **self-contained**. Everything it needs is here.

## Quick deploy (SF CLI)

```bash
# unzip the bundle
unzip seFrOrderSummary.zip -d seFrOrderSummary
cd seFrOrderSummary

# deploy to your demo org
sf project deploy start --source-dir force-app --target-org <your-org-alias>
```

## What's inside

- **LWC bundle** · `force-app/main/default/lwc/seFrOrderSummary/`
- **Apex classes** · `force-app/main/default/classes/`
  - `SE_FR_OrderSummaryController.cls` (local)

> Optional: product images read `Product2.Image_URL__c` (URL field) when it exists in your org (schema-safe: the component works without it). To enable images, create that field or set the `productImageFieldApiName` property to your own image field. It is not bundled because many orgs already have a field with this name and another type.

## Configure

Open App Builder, drop **`SE FR - OrderSummary`** (or search for it) on the right Lightning page, tune the properties.

See the component README inside this zip for the full property reference.
