# Install — seFrSubscribersList

This zip is **self-contained**. Everything it needs is here.

## Quick deploy (SF CLI)

```bash
# unzip the bundle
unzip seFrSubscribersList.zip -d seFrSubscribersList
cd seFrSubscribersList

# deploy to your demo org
sf project deploy start --source-dir force-app --target-org <your-org-alias>
```

## What's inside

- **LWC bundle** · `force-app/main/default/lwc/seFrSubscribersList/`
- No Apex required.

## Configure

Open App Builder, drop **`SE FR - SubscribersList`** (or search for it) on the right Lightning page, tune the properties.

See the component README inside this zip for the full property reference.
