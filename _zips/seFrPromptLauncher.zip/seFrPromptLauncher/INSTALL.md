# Install — seFrPromptLauncher

This zip is **self-contained**. Everything it needs is here.

## Quick deploy (SF CLI)

```bash
# unzip the bundle
unzip seFrPromptLauncher.zip -d seFrPromptLauncher
cd seFrPromptLauncher

# deploy to your demo org
sf project deploy start --source-dir force-app --target-org <your-org-alias>
```

## What's inside

- **LWC bundle** · `force-app/main/default/lwc/seFrPromptLauncher/`
- **Apex classes** · `force-app/main/default/classes/`
  - `SE_FR_PromptLauncherController.cls` (local)

## Configure

Open App Builder, drop **`SE FR - PromptLauncher`** (or search for it) on the right Lightning page, tune the properties.

See the component README inside this zip for the full property reference.
