# Install — seFrMyEvents

This zip is **self-contained**. Everything it needs is here.

## Quick deploy (SF CLI)

```bash
# unzip the bundle
unzip seFrMyEvents.zip -d seFrMyEvents
cd seFrMyEvents

# deploy to your demo org
sf project deploy start --source-dir force-app --target-org <your-org-alias>
```

## What's inside

- **LWC bundle** · `force-app/main/default/lwc/seFrMyEvents/`
- **Apex classes** · `force-app/main/default/classes/`
  - `SE_FR_AgendaController.cls` (shared, bundled here for self-containment)

## Configure

Open App Builder, drop **`SE FR - MyEvents`** (or search for it) on the right Lightning page, tune the properties.

See the component README inside this zip for the full property reference.

## Note on shared classes

Some Apex classes in `classes/` are also used by other components in the SE FR Component Library. Deploying this zip is safe even if those classes already exist in your org — Salesforce performs an idempotent overwrite (same code, same name).
