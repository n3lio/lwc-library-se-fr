# Install — seFrVisitQuickOrder

This zip is **self-contained**. Everything it needs is here.

## Quick deploy (SF CLI)

```bash
# unzip the bundle
unzip seFrVisitQuickOrder.zip -d seFrVisitQuickOrder
cd seFrVisitQuickOrder

# deploy to your demo org
sf project deploy start --source-dir force-app --target-org <your-org-alias>
```

## What's inside

- **LWC bundle** · `force-app/main/default/lwc/seFrVisitQuickOrder/`
- No Apex required.
- **Metadata** · Custom object Visit__c (+ 9 fields + tab)

> If your org already has the standard `Visit` object (Consumer Goods Cloud), do not deploy `Visit__c`: remove `objects/Visit__c` and `tabs/Visit__c.tab-meta.xml` from this bundle and point the component at `Visit`.

## Configure

Open App Builder, drop **`SE FR - VisitQuickOrder`** (or search for it) on the right Lightning page, tune the properties.

See the component README inside this zip for the full property reference.
