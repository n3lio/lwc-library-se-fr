import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getPromptSummary from '@salesforce/apex/SE_FR_AccountActionsController.getPromptSummary';

/**
 * CCO FR — Account Actions
 *
 * Compact toolbar on a record page:
 *   1. Primary action → launches a Screen Flow (configurable name). Record Id is passed as input.
 *   2. AI summary → calls Einstein Prompt Template via ConnectApi, renders the response as markdown.
 *
 * Ported from DBI retail-execution demo (dimAccountActions, 2026-07). Changes applied for library
 * compliance (see `_build/LIB_COMPLIANCE_SPECS.md`):
 *   - All DIM / client refs stripped
 *   - CSS variables renamed `--dim-*` → `--sefraa-*`
 *   - FR/EN i18n via LABELS + t() getter
 *   - Visit sObject hardcoded creation replaced by configurable Flow launch (rule 10.9)
 *   - Markdown parser kept inline (rule 10.4 — candidate for shared util `seFrMarkdown` later)
 *   - Apex pivoted to ConnectApi.EinsteinLLM (seFrContactCard pattern — no Named Credential needed)
 */
const LABELS = {
    en: {
        cardTitle: 'Quick actions',
        primaryActionDefault: 'Start visit',
        primaryActionLoading: 'Launching…',
        aiSummaryDefault: 'AI summary',
        aiSummaryLoading: 'Generating summary…',
        aiSummaryHeader: 'Einstein summary',
        aiSummaryEmpty: 'No summary returned.',
        aiSummaryError: 'Einstein unavailable.',
        close: 'Close',
        flowNotConfigured: 'Primary action Flow is not configured on this component.',
        flowModalTitle: 'Primary action',
        toastErrorTitle: 'Error',
        toastWarnTitle: 'Summary unavailable'
    },
    fr: {
        cardTitle: 'Actions rapides',
        primaryActionDefault: 'Démarrer une visite',
        primaryActionLoading: 'Ouverture…',
        aiSummaryDefault: 'Résumé IA',
        aiSummaryLoading: 'Génération du résumé…',
        aiSummaryHeader: 'Résumé Einstein',
        aiSummaryEmpty: 'Aucun résumé généré.',
        aiSummaryError: 'Einstein indisponible.',
        close: 'Fermer',
        flowNotConfigured: 'Aucun Flow configuré pour l’action primaire.',
        flowModalTitle: 'Action',
        toastErrorTitle: 'Erreur',
        toastWarnTitle: 'Résumé indisponible'
    }
};

export default class SeFrAccountActions extends NavigationMixin(LightningElement) {
    @api recordId;
    @api objectApiName;

    @api language = 'fr';
    @api cardTitle;
    @api accentColor;

    // Primary action
    @api disablePrimaryAction = false;
    @api primaryActionLabel;
    @api primaryActionIcon = 'utility:routing_offline';
    @api primaryActionFlowApiName;

    // AI summary
    @api disableAiSummary = false;
    @api aiSummaryLabel;
    @api promptTemplateApiName = 'einstein_gpt__summarizeAccountDefault';
    @api promptInputApiName = 'Input:Account';
    @api autoRunOnLoad = false;

    // Internal state
    isLaunchingPrimary = false;
    isSummarizing = false;
    summary;
    showFlowModal = false;
    _autoRan = false;

    // --- i18n -----------------------------------------------------------------------------------
    get _lang() { return this.language === 'fr' ? 'fr' : 'en'; }
    t(key) { return LABELS[this._lang][key] || key; }

    get resolvedCardTitle() { return this.cardTitle || this.t('cardTitle'); }
    get resolvedPrimaryLabel() { return this.primaryActionLabel || this.t('primaryActionDefault'); }
    get resolvedAiLabel() { return this.aiSummaryLabel || this.t('aiSummaryDefault'); }
    get primaryLoadingLabel() { return this.t('primaryActionLoading'); }
    get aiLoadingLabel() { return this.t('aiSummaryLoading'); }
    get summaryHeaderLabel() { return this.t('aiSummaryHeader'); }
    get showPrimary() { return !this.disablePrimaryAction; }
    get showAi() { return !this.disableAiSummary; }
    get hostStyle() {
        return this.accentColor ? `--sefraa-accent: ${this.accentColor};` : '';
    }

    // Flow inputs for the embedded <lightning-flow>
    get flowInputVariables() {
        return [{ name: 'recordId', type: 'String', value: this.recordId }];
    }

    // --- Lifecycle ------------------------------------------------------------------------------
    renderedCallback() {
        if (this.autoRunOnLoad && !this._autoRan && this.showAi && this.recordId) {
            this._autoRan = true;
            // Fire-and-forget — any error is toasted by the handler.
            this.handleSummarize();
        }
    }

    // --- Handlers -------------------------------------------------------------------------------
    handlePrimary() {
        if (this.isLaunchingPrimary) return;
        if (!this.primaryActionFlowApiName) {
            this.dispatchEvent(new ShowToastEvent({
                title: this.t('toastErrorTitle'),
                message: this.t('flowNotConfigured'),
                variant: 'warning'
            }));
            return;
        }
        this.isLaunchingPrimary = true;
        this.showFlowModal = true;
    }

    handleFlowStatusChange(event) {
        const status = event.detail.status;
        if (status === 'FINISHED' || status === 'FINISHED_SCREEN' || status === 'ERROR') {
            this.closeFlowModal();
        }
    }

    closeFlowModal() {
        this.showFlowModal = false;
        this.isLaunchingPrimary = false;
    }

    async handleSummarize() {
        if (this.isSummarizing) return;
        this.isSummarizing = true;
        this.summary = null;
        try {
            const result = await getPromptSummary({
                recordId: this.recordId,
                promptTemplateApiName: this.promptTemplateApiName,
                inputApiName: this.promptInputApiName
            });
            if (!result) {
                this.summary = this._markdownToHtml(this.t('aiSummaryEmpty'));
            } else {
                this.summary = this._markdownToHtml(result);
            }
        } catch (e) {
            const msg = (e && e.body && e.body.message) || (e && e.message) || this.t('aiSummaryError');
            this.dispatchEvent(new ShowToastEvent({
                title: this.t('toastWarnTitle'),
                message: msg,
                variant: 'warning'
            }));
        } finally {
            this.isSummarizing = false;
        }
    }

    handleCloseSummary() {
        this.summary = null;
    }

    // --- Markdown mini-parser (compliance rule 10.4) --------------------------------------------
    // Note: kept inline on purpose. If a 3rd component ports the same logic, factor into a shared
    // `seFrMarkdown` util (see LIB_COMPLIANCE_SPECS.md).
    _markdownToHtml(md) {
        if (!md) return '';
        let s = String(md).replace(/^```(?:markdown|md)?\s*\n?/, '').replace(/\n?```\s*$/, '');
        // Escape raw HTML before any transformation.
        s = s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        const lines = s.split(/\r?\n/);
        const out = [];
        let inList = false;
        const closeList = () => {
            if (inList) { out.push('</ul>'); inList = false; }
        };
        for (const raw of lines) {
            const line = raw.trim();
            if (line === '') { closeList(); continue; }
            let m;
            if ((m = line.match(/^###\s+(.+)$/))) { closeList(); out.push('<h4>' + m[1] + '</h4>'); continue; }
            if ((m = line.match(/^##\s+(.+)$/)))  { closeList(); out.push('<h3>' + m[1] + '</h3>'); continue; }
            if ((m = line.match(/^#\s+(.+)$/)))   { closeList(); out.push('<h2>' + m[1] + '</h2>'); continue; }
            if ((m = line.match(/^[-*]\s+(.+)$/))) {
                if (!inList) { out.push('<ul>'); inList = true; }
                out.push('<li>' + this._inlineMd(m[1]) + '</li>');
                continue;
            }
            if ((m = line.match(/^\d+\.\s+(.+)$/))) {
                if (!inList) { out.push('<ul>'); inList = true; }
                out.push('<li>' + this._inlineMd(m[1]) + '</li>');
                continue;
            }
            closeList();
            out.push('<p>' + this._inlineMd(line) + '</p>');
        }
        closeList();
        return out.join('');
    }

    _inlineMd(s) {
        s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
        s = s.replace(/(^|\s)\*([^*]+)\*(?=\s|$|[.,!?])/g, '$1<em>$2</em>');
        s = s.replace(/`([^`]+)`/g, '<code>$1</code>');
        return s;
    }
}
