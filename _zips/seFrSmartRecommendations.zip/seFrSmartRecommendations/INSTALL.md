# Install — seFrSmartRecommendations

This zip is **self-contained**. Everything it needs is here.

## Quick deploy (SF CLI)

```bash
# unzip the bundle
unzip seFrSmartRecommendations.zip -d seFrSmartRecommendations
cd seFrSmartRecommendations

# deploy to your demo org
sf project deploy start --source-dir force-app --target-org <your-org-alias>
```

## What's inside

- **LWC bundle** · `force-app/main/default/lwc/seFrSmartRecommendations/`
- No Apex required.

## Configure

Open App Builder, drop **`SE FR - SmartRecommendations`** (or search for it) on the right Lightning page, tune the properties.

See the component README inside this zip for the full property reference.
