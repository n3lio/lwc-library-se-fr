# Install — seFrSplashBanner

This zip is **self-contained**. Everything it needs is here.

## Quick deploy (SF CLI)

```bash
# unzip the bundle
unzip seFrSplashBanner.zip -d seFrSplashBanner
cd seFrSplashBanner

# deploy to your demo org
sf project deploy start --source-dir force-app --target-org <your-org-alias>
```

## What's inside

- **LWC bundle** · `force-app/main/default/lwc/seFrSplashBanner/`
- No Apex required.

## Configure

Open App Builder, drop **`SE FR - SplashBanner`** (or search for it) on the right Lightning page, tune the properties.

See the component README inside this zip for the full property reference.
