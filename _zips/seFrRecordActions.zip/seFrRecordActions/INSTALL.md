# Install — seFrRecordActions

This zip is **self-contained**. Everything it needs is here.

## Quick deploy (SF CLI)

```bash
# unzip the bundle
unzip seFrRecordActions.zip -d seFrRecordActions
cd seFrRecordActions

# deploy to your demo org
sf project deploy start --source-dir force-app --target-org <your-org-alias>
```

## What's inside

- **LWC bundle** · `force-app/main/default/lwc/seFrRecordActions/`
- **Child LWC** · `force-app/main/default/lwc/seFrFlowModal/` (used by this component)
- **Apex classes** · `force-app/main/default/classes/`
  - `SE_FR_AccountActionsController.cls` (local)

## Configure

Open App Builder, drop **`SE FR - RecordActions`** (or search for it) on the right Lightning page, tune the properties.

See the component README inside this zip for the full property reference.
