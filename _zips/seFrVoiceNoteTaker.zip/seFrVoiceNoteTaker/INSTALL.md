# Install — seFrVoiceNoteTaker

This zip is **self-contained**. Everything it needs is here.

## Quick deploy (SF CLI)

```bash
# unzip the bundle
unzip seFrVoiceNoteTaker.zip -d seFrVoiceNoteTaker
cd seFrVoiceNoteTaker

# deploy to your demo org
sf project deploy start --source-dir force-app --target-org <your-org-alias>
```

## What's inside

- **LWC bundle** · `force-app/main/default/lwc/seFrVoiceNoteTaker/`
- **Apex classes** · `force-app/main/default/classes/`
  - `SE_FR_VoiceNoteController.cls` (local)

## Configure

Open App Builder, drop **`SE FR - VoiceNoteTaker`** (or search for it) on the right Lightning page, tune the properties.

See the component README inside this zip for the full property reference.
